"""Resources for loading example data"""
