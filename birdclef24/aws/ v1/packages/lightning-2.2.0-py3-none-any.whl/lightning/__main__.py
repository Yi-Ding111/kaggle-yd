from lightning.app.cli.lightning_cli import main

if __name__ == "__main__":
    main()
