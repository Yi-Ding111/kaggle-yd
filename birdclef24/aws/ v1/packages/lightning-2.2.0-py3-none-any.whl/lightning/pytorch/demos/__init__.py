from lightning.pytorch.demos.transformer import LightningTransformer, Transformer, WikiText2  # noqa: F401
