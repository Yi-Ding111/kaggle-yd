from lightning.app.plugin.plugin import LightningPlugin

__all__ = ["LightningPlugin"]
