from lightning.app import LightningFlow


class ComponentA(LightningFlow):
    def run(self):
        print("hello from component A")
