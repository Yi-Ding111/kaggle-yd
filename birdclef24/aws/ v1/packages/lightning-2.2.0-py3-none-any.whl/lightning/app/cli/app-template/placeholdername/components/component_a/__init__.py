from placeholdername.components.component_a.component_a import ComponentA

__all__ = ["ComponentA"]
