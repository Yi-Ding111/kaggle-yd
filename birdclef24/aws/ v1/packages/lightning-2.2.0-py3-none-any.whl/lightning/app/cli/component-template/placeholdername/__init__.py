from placeholdername.component import TemplateComponent

__all__ = ["TemplateComponent"]
