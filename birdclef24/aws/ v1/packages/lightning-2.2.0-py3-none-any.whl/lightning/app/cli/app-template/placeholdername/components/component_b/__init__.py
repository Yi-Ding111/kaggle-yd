from placeholdername.components.component_b.component_a import ComponentB

__all__ = ["ComponentB"]
