#!/usr/bin/env python

from setuptools import find_packages, setup

setup(
    name="placeholdername",
    version="0.0.0",
    description="⚡ Lightning app ⚡ generated with command: lightning init app",
    author="",
    author_email="",
    # REPLACE WITH YOUR OWN GITHUB PROJECT LINK
    url="https://github.com/Lightning-AI/lightning-app-template",
    install_requires=[],
    packages=find_packages(),
)
