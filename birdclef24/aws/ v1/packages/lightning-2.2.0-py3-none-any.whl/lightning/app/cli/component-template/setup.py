#!/usr/bin/env python

from setuptools import find_packages, setup

setup(
    name="placeholdername",
    version="0.0.0",
    description="⚡ Lightning component ⚡ generated with command: lightning init component",
    author="",
    author_email="",
    # REPLACE WITH YOUR OWN GITHUB PROJECT LINK
    url="https://github.com/Lightning-AI/lightning-component-template",
    install_requires=[],
    packages=find_packages(),
)
