# Copyright The Lightning AI team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel


class WorkStatus(BaseModel):
    """The ``WorkStatus`` captures the status of a work according to the app."""

    stage: str
    timestamp: float
    reason: Optional[str] = None
    message: Optional[str] = None
    count: int = 1

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)

        assert self.timestamp > 0
        assert self.timestamp < (int(datetime.now().timestamp()) + 10)


class AppStatus(BaseModel):
    """The ``AppStatus`` captures the current status of the app and its components."""

    # ``True`` when the app UI is ready to be viewed
    is_ui_ready: bool

    # The statuses of ``LightningWork`` objects currently associated with this app
    work_statuses: Dict[str, WorkStatus]
