def is_multichannel(samples) -> bool:
    return samples.shape[1] > 1
